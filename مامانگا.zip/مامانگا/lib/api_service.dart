import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static Future<List<Map<String, String>>> fetchMangas(String query) async {
    final url = Uri.parse('https://api.mangadex.org/manga?limit=20&title=$query&includes[]=cover_art');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List mangas = data['data'];

      return mangas.map<Map<String, String>>((manga) {
        final id = manga['id'];
        final attributes = manga['attributes'];
        final title = attributes['title']['en'] ?? 'No Title';

        final coverRel = manga['relationships'].firstWhere(
          (rel) => rel['type'] == 'cover_art',
          orElse: () => null,
        );

        String? fileName = coverRel?['attributes']?['fileName'];
        String coverUrl = fileName != null
            ? 'https://uploads.mangadex.org/covers/$id/$fileName.256.jpg'
            : '';

        return {'id': id, 'title': title, 'cover': coverUrl};
      }).toList();
    } else {
      throw Exception('Failed to load mangas');
    }
  }
}
