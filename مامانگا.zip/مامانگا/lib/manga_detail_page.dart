import 'package:flutter/material.dart';
import 'chapter_service.dart';
import 'manga_reader_page.dart';
import 'favorites_service.dart';

class MangaDetailPage extends StatelessWidget {
  final String title, coverUrl, mangaId;

  const MangaDetailPage({
    super.key,
    required this.title,
    required this.coverUrl,
    required this.mangaId,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(title: Text(title)),
      body: Column(
        children: [
          Image.network(coverUrl, height: 200),
          ElevatedButton(
            onPressed: () async {
              final images = await ChapterService.fetchChapterImages(mangaId);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MangaReaderPage(images: images, title: title),
                ),
              );
            },
            child: const Text('خواندن'),
          ),
          ElevatedButton(
            onPressed: () async {
              await FavoritesService.addFavorite({
                'id': mangaId,
                'title': title,
                'cover': coverUrl,
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('به علاقه‌مندی‌ها اضافه شد')),
              );
            },
            child: const Text('افزودن به علاقه‌مندی'),
          ),
        ],
      ),
    );
  }
}
