import 'dart:convert';
import 'package:http/http.dart' as http;

class ChapterService {
  static Future<List<String>> fetchChapterImages(String mangaId) async {
    final response = await http.get(Uri.parse(
        'https://api.mangadex.org/at-home/server/$mangaId'));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final host = data['baseUrl'];
      final chapter = data['chapter'];
      final hash = chapter['hash'];
      final dataList = List<String>.from(chapter['data']);

      return dataList.map((fileName) => '$host/data/$hash/$fileName').toList();
    } else {
      throw Exception('Failed to load chapter images');
    }
  }
}
