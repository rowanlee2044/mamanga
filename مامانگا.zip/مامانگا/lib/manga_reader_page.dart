import 'package:flutter/material.dart';

class MangaReaderPage extends StatelessWidget {
  final List<String> images;
  final String title;

  const MangaReaderPage({super.key, required this.images, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      backgroundColor: Colors.black,
      body: ListView.builder(
        itemCount: images.length,
        itemBuilder: (context, index) {
          return Image.network(images[index]);
        },
      ),
    );
  }
}
