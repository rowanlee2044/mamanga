import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class FavoritesService {
  static const String key = 'favorites';

  static Future<void> addFavorite(Map<String, String> manga) async {
    final prefs = await SharedPreferences.getInstance();
    final list = await getFavorites();
    list.add(manga);
    prefs.setString(key, jsonEncode(list));
  }

  static Future<void> removeFavorite(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final list = await getFavorites();
    list.removeWhere((manga) => manga['id'] == id);
    prefs.setString(key, jsonEncode(list));
  }

  static Future<List<Map<String, String>>> getFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(key);
    if (jsonString == null) return [];
    final List decoded = jsonDecode(jsonString);
    return decoded.cast<Map<String, String>>();
  }
}
