import 'package:flutter/material.dart';
import 'manga_detail_page.dart';
import 'api_service.dart';

class NetflixStyleHome extends StatelessWidget {
  const NetflixStyleHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: FutureBuilder(
        future: ApiService.fetchMangas(""),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("خطا: ${snapshot.error}"));
          }
          final mangas = snapshot.data ?? [];
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              const Text('پیشنهاد شده‌ها',
                  style: TextStyle(color: Colors.white, fontSize: 20)),
              SizedBox(
                height: 200,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: mangas.length,
                  itemBuilder: (context, index) {
                    final manga = mangas[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MangaDetailPage(
                              title: manga['title']!,
                              coverUrl: manga['cover']!,
                              mangaId: manga['id']!,
                            ),
                          ),
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.network(manga['cover'] ?? ''),
                      ),
                    );
                  },
                ),
              )
            ],
          );
        },
      ),
    );
  }
}
