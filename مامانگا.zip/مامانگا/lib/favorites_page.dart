import 'package:flutter/material.dart';
import 'favorites_service.dart';
import 'manga_detail_page.dart';

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  List<Map<String, String>> favorites = [];

  @override
  void initState() {
    super.initState();
    loadFavorites();
  }

  Future<void> loadFavorites() async {
    final favs = await FavoritesService.getFavorites();
    setState(() => favorites = favs);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(title: const Text('علاقه‌مندی‌ها')),
      body: favorites.isEmpty
          ? const Center(child: Text('لیست علاقه‌مندی خالیه'))
          : ListView.builder(
              itemCount: favorites.length,
              itemBuilder: (context, index) {
                final manga = favorites[index];
                return ListTile(
                  title: Text(manga['title'] ?? '', style: const TextStyle(color: Colors.white)),
                  leading: Image.network(manga['cover'] ?? ''),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MangaDetailPage(
                          title: manga['title']!,
                          coverUrl: manga['cover']!,
                          mangaId: manga['id']!,
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
